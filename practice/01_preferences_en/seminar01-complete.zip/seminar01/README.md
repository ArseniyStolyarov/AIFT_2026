# Семинар 1 — Preferences and utility

Полная папка семинара: задания, решения, LaTeX и готовые PDF.

- `seminar-worksheet.pdf` — листок для студентов.
- `seminar-solutions.pdf` — решения и рекомендации для семинариста.
- `seminar-worksheet.tex` — основной файл листка.
- `seminar-problems.tex` — текст тем и задач; редактируйте здесь.
- `seminar-solutions.tex` — текст решений и их основной LaTeX-файл.
- `nesarticle.sty` — оформление.
- `assets/nes-english.pdf` — логотип.

## Сборка

Установите TeX Live или MiKTeX с XeLaTeX и шрифт DejaVu Sans.
В этой папке выполните `bash build.sh`.

В Overleaf загрузите всё содержимое папки с сохранением `assets/`,
выберите компилятор XeLaTeX и основной файл `seminar-worksheet.tex`.
Для решений выберите основным файлом `seminar-solutions.tex`.

Архив содержит ответы: студентам передавайте только `seminar-worksheet.pdf`.
